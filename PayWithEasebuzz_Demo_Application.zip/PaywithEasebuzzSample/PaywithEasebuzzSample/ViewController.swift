//
//  ViewController.swift
//  SampleApp
//
//  Created by Pro Retina on 13/12/17.
//  Copyright © 2017 Pro Retina. All rights reserved.
//

import UIKit
import Easebuzz

class ViewController: UIViewController,PayWithEasebuzzCallback {
    
    @IBOutlet weak var txtName: UITextField!
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtMobileNo: UITextField!
    @IBOutlet weak var txtAmount: UITextField!
    @IBOutlet weak var txtProductInfo: UITextField!
    @IBOutlet weak var txtUniqueID: UITextField!
    @IBOutlet weak var txtAddress1: UITextField!
    @IBOutlet weak var txttxtAddress2: UITextField!
    @IBOutlet weak var viewOfPayementStatus: UIView!
    @IBOutlet weak var mainScroll: UIScrollView!
    @IBOutlet weak var lblPaymentStatusTitle: UILabel!
    @IBOutlet weak var lblPayementStatusSubTitle: UILabel!
    @IBOutlet weak var lblPaymentStatusDescription: UILabel!
    @IBOutlet weak var viewOfScrollFront: UIView!
    
    var strmerchantUsername = ""
    var strMobileNumber = ""
    var paymentPurpose = ""
    var sub_merchant_id:Int?
    var imageName = ""
    
    func PEBCallback(data: [String : AnyObject]) {  // paywithEasebuzz call back and handle payment response
        let payment_response = data["payment_response"]
        
        if payment_response as? [String:Any] != nil {
            print("Json response pavan test")
            print(payment_response)
        }else{
            print("String response")
        }
        self.handlePaymentResponse(data: data)
    }
    
    func handlePaymentResponse(data:[String: AnyObject])  {
        let payment_response = data["payment_response"]
        let result = data["result"] as! String
        
        if result.count > 0 {
            lblPayementStatusSubTitle.text = result
            lblPaymentStatusDescription.text = ""
        }
        
        switch result {
        case StaticDataModel.TXN_SUCCESS_CODE,StaticDataModel.TXN_FAILED_CODE,StaticDataModel.TXN_USERCANCELLED_CODE:
            DispatchQueue.main.async {
                self.mainScroll.isHidden = true
                
                if ((payment_response as? [String : AnyObject?]) != nil) {
                    // Proper response in json
                }else{
                    // Not json
                }
            }
        default:
            DispatchQueue.main.async {
                self.viewOfPayementStatus.isHidden = false
                self.mainScroll.isHidden = true
                //self.btnPayNow.isHidden = true
            }
            break
        }
        self.viewOfPayementStatus.isHidden = false
        self.mainScroll.isHidden = true
    }
    
    @IBAction func btnPaymentStatusHide(_ sender: Any) {
        self.viewOfPayementStatus.isHidden = true
        self.mainScroll.isHidden = false
        self.navigationController?.popToRootViewController(animated: true)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print("Client App Loaded")
        
        // Set ToolBar
        setUpKeyBoardToolBar()
        setNavigationBackButton()
        setTapGestureToView()
        // Initial Setting for hiiden status view and scroll view
        mainScroll.isHidden = false
        viewOfPayementStatus.isHidden = true
        
        
        self.edgesForExtendedLayout = []
    }
    
    func setTapGestureToView()  {
        let tap = UITapGestureRecognizer.init(target: self, action: #selector(self.tapOnView(gesture:)))
        self.viewOfScrollFront.addGestureRecognizer(tap)
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
    }
    
    func setNavigationBackButton() {
        let backButton = UIButton()
        backButton.frame = CGRect(x: 0, y:0, width:30,height: 30)
        let back_image = UIImage.init(named: "ImgBack")
        backButton.setImage(back_image, for: .normal)
        let leftBarButtonItem = UIBarButtonItem(customView: backButton)
        self.navigationItem.setLeftBarButton(leftBarButtonItem, animated: true)
        
        let widthConstraint = backButton.widthAnchor.constraint(equalToConstant: 30)
        let heightConstraint = backButton.heightAnchor.constraint(equalToConstant: 30)
        heightConstraint.isActive = true
        widthConstraint.isActive = true
        backButton.addTarget(self,action: #selector(self.back(sender:)), for: .touchUpInside)
        
        // Set Navigation bar settings
        self.navigationController?.navigationBar.backgroundColor = UIColor.purple
        self.navigationController?.navigationBar.isTranslucent = false
        self.navigationController?.navigationBar.barTintColor = UIColor.purple
        self.title = stringConstants.navigationTitle
        self.navigationController?.navigationBar.titleTextAttributes =  [NSAttributedStringKey.foregroundColor: UIColor.white]
    }
    @objc func tapOnView(gesture: UITapGestureRecognizer){
        self.view.endEditing(true)
    }
    @objc func back(sender: UIButton) {
        // self.navigationController?.popViewController(animated: true)
        self.navigationController?.popToRootViewController(animated: true)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func validateAllTextField() -> Bool {
        self.view.endEditing(true)
        if txtMobileNo.text?.count == 0 {
            self.view.makeToast(stringConstants.emptyMobileMsg)
            return false
        } else if LocalValidation.isValidPhone(testPhoneNumber: txtMobileNo.text!){
            self.view.makeToast(stringConstants.validMobileMsg)
            return false
        }else if txtName.text?.count == 0{
            self.view.makeToast("Please enter name")
            return false
        }else if txtEmail.text?.count == 0 {
            self.view.makeToast("Please enter email")
            return false
        } else if LocalValidation.isValidEmail(testEmail: txtEmail.text!){
            self.view.makeToast("Please enter valid email")
            return false
        }
        else if txtAmount.text?.count == 0 {
            self.view.makeToast("Please enter Amount")
            return false
        } else{
            return true
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    @IBAction func openPEB(_ sender: Any) {  // Call this method on payment button
        
        if validateAllTextField() {
            self.initiatePaymentAction(strTransationId: "1XXXXX313")
            //            self.easepaySaveInfo()
        }
    }
    
    func initiatePaymentAction(strTransationId:String) {
        //  Kindly enter your key-salt provided by Easebuzz team.
        let key =  "XXXXXXXX"
        let salt =  "XXXXXXX"
        
        // required parameters dictionary. Pass all parameter to Payment class. All parameter description given in documentation.
        let orderDetails = [
            "txnid": strTransationId,
            "amount":txtAmount.text!,
            "productinfo":  txtProductInfo.text!,
            "firstname":txtName.text!,
            "email":txtEmail.text!,
            "phone":txtMobileNo.text!,
            "surl": "https://demo.in/success"  ,   // Add your success url
            "furl": "https://demo.in/fail",  // Add your fail url
            "key":key,
            "udf1":"udf1",
            "udf2":"udf2",
            "udf3":"udf3",
            "udf4":"udf4",
            "udf5":"udf5",
            "udf6":"",
            "udf7":"",
            "udf8":"",
            "udf9":"",
            "udf10":"",
            "address1":txtAddress1.text!,
            "address2":txttxtAddress2.text!,
            "city":"Pune",
            "state":"Maharashtra",
            "country":"India",
            "zipcode":"411030",
            "merchant_id": stringConstants.strMerchantId,
            "isMobile":"1",
            "sub_merchant_id": "",
            "unique_id":  txtUniqueID.text!,
            "salt": salt,
            "pay_mode": "production"   // "test"  for testing purpose
            ] as [String:String]
        
        let payment = Payment.init(customerData: orderDetails)
        let paymentValid = payment.isValid().validity
        
        if !paymentValid{
            print("Invalid print")
        }else {
            PayWithEasebuzz.setUp(pebCallback: self)
            PayWithEasebuzz.invokePaymentOptionsView(paymentObj: payment, isFrom: self)
        }
    }
}


extension ViewController:UITextFieldDelegate,UITextViewDelegate{
    
    func setUpKeyBoardToolBar(){
        let toolbarDone = UIToolbar.init()
        toolbarDone.sizeToFit()
        
        let barBtnDone = UIBarButtonItem.init(
            barButtonSystemItem: UIBarButtonSystemItem.done,
            target: self, action: #selector(ViewController.doneButton_Clicked(sender:))
        )
        let extraSpace = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        
        toolbarDone.items = [extraSpace,barBtnDone]
        toolbarDone.barStyle = UIBarStyle.default
        txtMobileNo.inputAccessoryView = toolbarDone
        txtAmount.inputAccessoryView = toolbarDone
    }
    
    @objc func doneButton_Clicked(sender: UIBarButtonItem) {
        if txtMobileNo.isEditing {
            txtAmount.becomeFirstResponder()
        }else if txtAmount.isEditing {
            txtProductInfo.becomeFirstResponder()
        }
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if textField == txtName {
            txtEmail.becomeFirstResponder()
        }else if textField == txtEmail {
            txtMobileNo.becomeFirstResponder()
        }else if textField == txtMobileNo {
            txtAmount.becomeFirstResponder()
        }else if textField == txtAmount {
            txtProductInfo.becomeFirstResponder()
        }else if textField == txtProductInfo {
            txtUniqueID.becomeFirstResponder()
        }else if textField == txtUniqueID {
            txtAddress1.becomeFirstResponder()
        }else if textField == txtAddress1 {
            txttxtAddress2.becomeFirstResponder()
        }else if textField == txttxtAddress2 {
            txttxtAddress2.resignFirstResponder()
        }
        return true
    }
}





