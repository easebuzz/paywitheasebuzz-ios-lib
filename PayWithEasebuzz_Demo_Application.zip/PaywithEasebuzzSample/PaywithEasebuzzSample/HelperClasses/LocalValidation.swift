//
//  Validation.swift
//  Demo
//
//  Created by Pro Retina on 12/12/17.
//  Copyright © 2017 easebuzz. All rights reserved.
//

import Foundation
class LocalValidation {
    class func isValidEmail(testEmail:String) -> Bool
    {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}"
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        let result = emailTest.evaluate(with: testEmail)
        
        if result == true {
            return false
        }
        else{
            return true
        }
    }
    
   class func isValidPhone(testPhoneNumber: String) -> Bool {
       // let PHONE_REGEX = "^((\\+)|(00))[0-9]{6,14}$"
        let PHONE_REGEX = "^[0-9]{6,14}$"
        let phoneTest = NSPredicate(format: "SELF MATCHES %@", PHONE_REGEX)
        let result =  phoneTest.evaluate(with: testPhoneNumber)
        if result == true {
            return false
        }
        else{
            return true
        }
    }
    
   
}
