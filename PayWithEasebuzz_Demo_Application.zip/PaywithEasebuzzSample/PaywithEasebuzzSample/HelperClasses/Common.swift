//
//  Common.swift
//  EasebuzzDemoApp
//
//  Created by Pro Retina on 21/12/17.
//  Copyright © 2017 Pro Retina. All rights reserved.
//

import Foundation

//struct colors
//{
//    static let navigationColor = UIColor(red: 23/255.0, green: 33/255.0, blue: 45/255.0, alpha: 1.0)
//    static let barTintColor =   UIColor(red: 23/255.0, green: 33/255.0, blue: 45/255.0, alpha: 1.0)
//    static let redShade = UIColor(red: 183/255.0, green: 28/255.0, blue: 28/255.0, alpha: 1.0)
//    static let placeHolderColor = UIColor(red: 136/255.0, green: 136/255.0, blue: 136/255.0, alpha: 1.0)
//}

struct stringConstants
{
    static let contactUs = "https://easebuzz.in/contact"
    static let terms = "https://easebuzz.in/terms"
    static let privarcy = "https://easebuzz.in/privacy"
    static let refund = "https://easebuzz.in/cancellations"
    static let faq = "https://easebuzz.in/faq"
    
    static let strMerchantId =  ""
    static let navigationTitle = "Demo"
    static let errroMessage = "Sorry something went wrong,Please try again later"
    static let emptyMobileMsg = "Please enter mobile number"
    static let validMobileMsg = "Please enter valid phone number"
    static let emptyOTPMessage = "Please enter OTP"
    static let validOTPMessage = "Please enter valid OTP"
}
