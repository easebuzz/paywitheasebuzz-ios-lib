//
//  Easebuzz.h
//  Easebuzz
//
//  Created by Pro Retina on 14/12/17.
//  Copyright © 2017 Pro Retina. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Easebuzz.
FOUNDATION_EXPORT double EasebuzzVersionNumber;

//! Project version string for Easebuzz.
FOUNDATION_EXPORT const unsigned char EasebuzzVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Easebuzz/PublicHeader.h>


